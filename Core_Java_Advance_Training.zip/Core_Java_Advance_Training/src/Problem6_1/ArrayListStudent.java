package Problem6_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArrayListStudent {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		int n;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter the number of stuents: ");
		n=sc.nextInt();
		System.out.println("enter the Student name:");
		for(int i=0;i<n;i++){
			a.add(sc.next());
		}
		System.out.println("student list:");
		for(String s:a)
		{
			System.out.println("enter the name to be searched:");
			String st=sc.next();
			int position=Collections.binarySearch(a, st);
			System.out.println("position of " +st+ " is:"+position);
		}
	}

}
