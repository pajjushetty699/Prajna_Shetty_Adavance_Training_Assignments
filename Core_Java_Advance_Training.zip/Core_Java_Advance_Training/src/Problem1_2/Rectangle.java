package Problem1_2;

public class Rectangle {
	private int length;
	private int breadth; 
	private int area;
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public Rectangle(){
		
	}
	public  Rectangle(int length,int breadth){
		this.length=length;
		this.breadth=breadth;
	}
	void areaOfRectangle(int length,int breadth){
		area=length*breadth;
	}
 void displayAllInformation(){
	System.out.println("The length of the rectagle is:"+length+"\nThe breadth of the rectangle is: "+breadth+"\nThe area of the Rectangle:"+area);
	
}
 public void areaOfTestRectangle(){
	 System.out.println("lenth:"+length+"breadth:"+breadth+"area:"+length*breadth);
 }
public static void main(String[] args) {
	Rectangle r1=new Rectangle(4,5);
	r1.areaOfRectangle(4, 5);
	r1.displayAllInformation();	
	Rectangle r=new Rectangle();
	r.setLength(6);
	r.setBreadth(5);
	r.setArea(6*5);
	System.out.println("length from getter: "+r.getLength()+"\nbreadth from getter: "+r.getBreadth()+"\narea from getter: "+r.getArea());
}
}
