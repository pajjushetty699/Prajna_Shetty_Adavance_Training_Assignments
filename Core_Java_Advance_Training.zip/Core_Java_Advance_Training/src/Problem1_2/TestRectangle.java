package Problem1_2;

import java.util.Scanner;
public class TestRectangle  {

	public static void main(String[] args) {
		
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<=5;i++){
		System.out.println("Enter thee breadth nd length of the rectangle");
		int len=sc.nextInt();
		int bre=sc.nextInt();
		Rectangle r=new Rectangle(len,bre);
		r.areaOfTestRectangle();
	}
	
	}

}
