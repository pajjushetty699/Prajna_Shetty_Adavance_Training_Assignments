package Problem5_1;

public class StringM {

	public static void main(String[] args) {
		String str="JAVA is Simple";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		String[] words=str.split("\\s");
		for(String w:words){
			System.out.print(w.charAt(0));
			System.out.print("");
		}
		System.out.println("");
		String[]words0=str.split("\\s");
		for(String w:words0){
			System.out.print(w);
		}
		StringBuilder words1=new StringBuilder("JAVA is Simple");
		Object words21;
		System.out.println("String="+words1.toString());
		StringBuilder reverseStr=words1.reverse();
		System.out.println("Reverse String="+reverseStr.toString());
		System.out.println("length of string "+str.length());

	}

}
