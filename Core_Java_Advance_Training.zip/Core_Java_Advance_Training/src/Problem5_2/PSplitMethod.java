package Problem5_2;

public class PSplitMethod {

	public static void main(String[] args) {
		String str=("23  +      45   -(   343   /   12 )");
		String[] s=str.split("\\s");
		for(String w1:s){
			System.out.println(w1);
		}
	}

}
