package Problem1_1;

import java.util.Scanner;

public class EvenNumber {
	public static void main(String[] args) {
		int n ;
		Scanner s =new Scanner(System.in);
		System.out.println("enter the number" );
		n= s.nextInt();
		int i=n/2;
	if(n%2==0){
			System.out.println(n+"Is an even number");
	}
		
	else{
		System.out.println(n+"Is not an even number");
	}

	}
	}

