package Problem2_3;

public class IntArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] ar=new int[]{1,2,3,4,5};
int sum=0;
for(int i=0;i<ar.length;i++){
	sum=sum+ar[i];
}
System.out.println("sum of all the elements of an array: " +sum);
	}

}
