package Problem1_3;

import java.util.Scanner;



public class MainBook {
	/*public void createBook(){
		Book b[]=new Book[2];
		b[1]=new Book("Java Programming",350.50);
		b[2]=new Book("Let Us C",200.00);
	for(int i=0;i<b.length;i++){
		b[i].display();
		System.out.println("");
	}
	}
	public void showBook(){
		createBook();
	}*/

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the book name");
		String book_title=s.nextLine();
		System.out.println("enter the book name");
		int book_price=s.nextInt();
		s.nextLine();
		Book b=new Book();
		b.setBook_title(book_title);
		b.setBook_price(book_price);
		System.out.println(" book_title:"+b.getBook_title());
		System.out.println("book_price:"+b.getBook_price());
		
	}

}
