package Problem4_1;

public class BankAccount {
	int accunt_num;
    String name;
    String account_type;
    double balance;

	public int getAccunt_num() {
		return accunt_num;
	}

	public void setAccunt_num(int accunt_num) {
		this.accunt_num = accunt_num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public double getBalance(){
		if(balance<1000){
			try{
				throw new NumberFormatException();
			}
			catch(NumberFormatException ex){
				System.out.println("Balance is low"+balance);
			}
		}
	return balance;
	}
	public void setBalance(double balance){
		this.balance=balance;
	}
	public BankAccount(){
		this.accunt_num=200;
		this.name="amal";
		this.account_type="saving";
		this.balance=500;
		}
	public BankAccount(int account_number,String name,String account_type,double balance)
	{
		this.accunt_num=accunt_num;
		this.name=name;
		this.account_type=account_type;
		this.balance=balance;
	}
	void deposit(double amunt){
		if(amunt<0){
			try{
				throw new NumberFormatException();
			}
			catch(NumberFormatException ex){
				System.out.println("negative account cant be deposited");
			}
		}
		else{
			balance=getBalance()+amunt;
			System.out.println("current balance is= "+balance);
			
		}
	}
	public void withdraw(double amunt){
		if(amunt>1000){
			try{
				throw new NumberFormatException();
			}
	    catch(NumberFormatException ex){
	    	System.out.println("we cant deposit amount insufficent balance");
	    }
		}
		else{
			balance=getBalance()-amunt;
			System.out.println("Current Balance is ="+balance);
		}
	}
	void display(){
		System.out.println("Balance is= "+getBalance());
	}
	public static void main(String[] args) {
		BankAccount b=new BankAccount();
		b.deposit(3000);
		b.display();
		b.withdraw(500);
		b.display();
		b.withdraw(2000);
		b.getBalance();
		b.display();
		
	}

}
