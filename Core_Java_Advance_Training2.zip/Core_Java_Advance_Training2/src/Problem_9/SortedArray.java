package Problem_9;

import java.util.HashMap;
import java.util.Map;

public class SortedArray {
public static void findFrequency(int[]num,int left,int right,Map<Integer,Integer>freq){
	if(left>right){
		return;
	}
	if (num[left]==num[right]){
		Integer count=freq.get(num[left]);
		if(count==null){
			count=0;
		}
		freq.put(num[left],count+(right-left+1));
		return;
	}
	int mid=(left+right)/2;
	findFrequency(num,left,mid,freq);
	findFrequency(num,mid+1,right,freq);

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] num={2,2,2,4,4,4,5,5,6,8,8,9,0,1,6,7,7,1};
Map<Integer,Integer>freq=new HashMap<>();
findFrequency(num,0,num.length-1,freq);
System.out.println(freq);
	}

}
