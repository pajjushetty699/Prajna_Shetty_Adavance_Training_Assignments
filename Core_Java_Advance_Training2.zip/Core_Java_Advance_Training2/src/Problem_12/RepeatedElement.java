package Problem_12;

import java.util.HashSet;

public class RepeatedElement {

	public static void main(String[] args) {
		int[] a= {1,2,3,10,6,4,3,7,10};
		int temp=-1;
		HashSet<Integer>hs=new HashSet<>();
		for(int i=a.length-1; i>=0;i--)
		{
			if(hs.contains(a[i])) {
				temp=i;
			}
			else
			{
				hs.add(a[i]);
			}
		}
		if(temp!=-1) {
			System.out.println("first repeated element is "+a[temp]);
		}
		else {
			System.out.println("first repeated element not found");
		}
	}
}
